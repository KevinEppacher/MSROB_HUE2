#include "ros/ros.h"
#include <sstream>
#include "std_msgs/String.h"


int main(int argc, char **argv)
{
  double frequenz=10;
  ros::init(argc, argv, "publisher");
  ros::NodeHandle n;
  ros::Publisher chatter_pub=n.advertise<std_msgs::String>("chatter", 1000); ;
  ros::Rate loop_rate(frequenz);



  double Periodendauer=1/frequenz;
  double x_new, x_old=0;
  double y_new, y_old=0;
  double theta_new_Degree, theta_old_Degree=0;
  double baseline;
  double r;
  double timestamp_new=0, timestamp_old=0;
  double x_Geschw, y_Geschw, theta_Geschw;
  double winkelgeschw_linkes_Rad, winkelgeschw_rechtes_Rad;

  ros::param::get("/x_new", x_new);
  ros::param::get("/y_new", y_new);
  ros::param::get("/theta_new_Degree", theta_new_Degree);
  ros::param::get("/baseline", baseline);
  ros::param::get("/r", r);

  double theta_new_Rad=theta_new_Degree*M_PI/180, theta_old_Rad=theta_new_Degree*M_1_PI/180;
  double r_l=r, r_r=r;
  double l_l=baseline/2, l_r=baseline/2;


  while (ros::ok())
  {
    //ros::Time current_time, last_time;
    //current_time = ros::Time::now();
    //last_time = ros::Time::now();
    timestamp_new=timestamp_new+Periodendauer;
    double dt = (timestamp_new - timestamp_old);

    x_Geschw=(x_new-x_old)/dt;
    y_Geschw=(y_new-y_old)/dt;
    theta_Geschw=(theta_new_Rad-theta_old_Rad)/dt;

    winkelgeschw_linkes_Rad=(cos(theta_new_Rad)*x_Geschw-sin(theta_new_Rad)*y_Geschw-l_l*theta_Geschw)/r_l;
    winkelgeschw_rechtes_Rad=(cos(theta_new_Rad)*x_Geschw-sin(theta_new_Rad)*y_Geschw+l_r*theta_Geschw)/r_r;

    ROS_INFO("Timestamp: %lf || Winkelgeschw. linkes Rad: %lf || Winkelgeschw. rechtes Rad: %lf",timestamp_new, winkelgeschw_linkes_Rad, winkelgeschw_rechtes_Rad); 
    //ROS_INFO("x_Geschw: %lf || y_Geschw: %lf || theta_Geschw: %lf",x_Geschw, y_Geschw, theta_Geschw); 
    
    std_msgs::String msg;
    std::stringstream ss;
    ss << "Winkelgeschwindigkeit linkes Rad: " << winkelgeschw_linkes_Rad;
    ss << "Winkelgeschwindigkeit rechtes Rad: " << winkelgeschw_rechtes_Rad;

    msg.data = ss.str();
    chatter_pub.publish(msg);   
    
    ros::spinOnce();
    loop_rate.sleep();
    //last_time = current_time;

    timestamp_old=timestamp_new;
  }


  return 0;
}
