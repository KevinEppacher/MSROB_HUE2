//#include "../src/robot.h"
/*
robot::robot(){}

//robot::robot(double x_R, double y_R, double theta_R, double x_G, double y_G, double theta_G, double k_alpha, double k_beta,double k_rho ){}

void robot::linear_control()
{
    /*
        if(on_off_switch==true)
        {
            rho=sqrt(pow((x_G-x_R),2)+pow((y_G-y_R),2));
            alpha=theta_R+atan2(((y_G-y_R)*(y_G-y_R)),((x_G-x_R)*(x_G-x_R)));
            beta=theta_G-theta_R-alpha;
            theta_R_Geschw=k_alpha*alpha+k_beta*beta;
            x_R_Gesch=k_rho*rho;
            current_rho=rho;
        }
        if(current_rho>last_rho)
        {
            x_R_Gesch=0;
        }
        if(rho<0.25)
        {
            x_R_Gesch=0;
        }

        if(on_off_switch==false)
        {
            x_R_Gesch=0;
            theta_R_Geschw=0;
        }
        */
