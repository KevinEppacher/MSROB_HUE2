#!/bin/bash
roslaunch eppacher_hw2 eppacher_hw2_launchfile_poses.launch